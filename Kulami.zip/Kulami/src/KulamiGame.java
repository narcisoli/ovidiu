/**
 * Kulami game main
 */
public class KulamiGame extends Game{


    public void startGame(){

    }

    public void setCoordinates(){

    }

}

